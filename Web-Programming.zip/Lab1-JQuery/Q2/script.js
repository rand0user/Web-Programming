function appendValue(value) {
    document.getElementById("result").value += value;
}
function clearResult() {
    document.getElementById("result").value = "";
}
function toggleSign() {
    let currentValue = document.getElementById("result").value;
    if (currentValue.startsWith("-")) {
        document.getElementById("result").value = currentValue.substring(1);
    } else {
        document.getElementById("result").value = "-" + currentValue;
    }
}
function calculateResult() {
    try {
        let result = eval(document.getElementById("result").value);
        document.getElementById("result").value = result;
    } catch (error) {
        document.getElementById("result").value = "Error";
    }
}