from django.shortcuts import render

def index(request):
    manufacturers = ['Toyota', 'Ford', 'BMW', 'Audi']
    return render(request, 'car_app/index.html', {'manufacturers': manufacturers})

def result(request):
    if request.method == 'POST':
        manufacturer = request.POST.get('manufacturer')
        model = request.POST.get('model')
        return render(request, 'car_app/result.html', {'manufacturer': manufacturer, 'model': model})
    return render(request, 'car_app/result.html')
