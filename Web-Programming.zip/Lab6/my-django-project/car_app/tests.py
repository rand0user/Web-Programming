from django.test import TestCase
from django.urls import reverse

class CarAppTests(TestCase):
    def test_index_view(self):
        response = self.client.get(reverse('car_app:index'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'car_app/index.html')

    def test_result_view(self):
        response = self.client.post(reverse('car_app:result'), {
            'manufacturer': 'Toyota',
            'model': 'Camry'
        })
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'car_app/result.html')
        self.assertContains(response, 'Toyota')
        self.assertContains(response, 'Camry')