# My Django Project

This is a simple Django project that demonstrates the transfer of multiple parameters between web pages. The application allows users to select a car manufacturer from a dropdown list, enter a model name, and submit the form to view the selected manufacturer and model on a new page.

## Project Structure

```
my-django-project
├── my_django_project
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
├── car_app
│   ├── __init__.py
│   ├── admin.py
│   ├── apps.py
│   ├── models.py
│   ├── tests.py
│   ├── views.py
│   ├── urls.py
│   └── templates
│       └── car_app
│           ├── index.html
│           └── result.html
├── manage.py
└── README.md
```

## Setup Instructions

1. **Clone the repository:**
   ```
   git clone <repository-url>
   cd my-django-project
   ```

2. **Create a virtual environment:**
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. **Install dependencies:**
   ```
   pip install django
   ```

4. **Run migrations:**
   ```
   python manage.py migrate
   ```

5. **Run the development server:**
   ```
   python manage.py runserver
   ```

6. **Access the application:**
   Open your web browser and go to `http://127.0.0.1:8000/`.

## Usage

- On the homepage, select a car manufacturer from the dropdown list and enter the model name in the text box.
- Click the submit button to view the selected manufacturer and model on the results page.

## License

This project is licensed under the MIT License.