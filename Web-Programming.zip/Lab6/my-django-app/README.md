# My Django App

This is a simple Django application that demonstrates the use of forms, sessions, and navigation between pages.

## Project Structure

```
my-django-app
├── my_django_app
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   ├── asgi.py
│   └── views.py
├── templates
│   ├── firstPage.html
│   └── secondPage.html
├── manage.py
└── README.md
```

## Features

- A form on the first page to collect user information (Name, Roll, Subjects).
- Navigation to a second page that displays the submitted information.
- Ability to return to the first page from the second page.

## Setup Instructions

1. **Clone the repository:**
   ```
   git clone <repository-url>
   cd my-django-app
   ```

2. **Install dependencies:**
   Make sure you have Python and Django installed. You can install Django using pip:
   ```
   pip install django
   ```

3. **Run the application:**
   Use the following command to start the development server:
   ```
   python manage.py runserver
   ```

4. **Access the application:**
   Open your web browser and go to `http://127.0.0.1:8000/`.

## Usage

- Fill in the form on the first page and click the submit button to navigate to the second page.
- The second page will display the submitted information.
- Click the button on the second page to return to the first page.

## License

This project is licensed under the MIT License - see the LICENSE file for details.