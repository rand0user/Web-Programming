from django.db import models

class Student(models.Model):
    name = models.CharField(max_length=100)
    date_of_birth = models.DateField()
    address = models.TextField()
    contact_number = models.CharField(max_length=15)
    email = models.EmailField()
    english_marks = models.DecimalField(max_digits=5, decimal_places=2)
    physics_marks = models.DecimalField(max_digits=5, decimal_places=2)
    chemistry_marks = models.DecimalField(max_digits=5, decimal_places=2)

    def calculate_percentage(self):
        total = self.english_marks + self.physics_marks + self.chemistry_marks
        return round((total / 300) * 100, 2)

    def __str__(self):
        return f"{self.name} - {self.email}"
