from django.shortcuts import render, redirect
from .forms import StudentForm
from .models import Student

def student_form(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            student = form.save()
            
            # Prepare data for display
            student_data = f"""
            Name: {student.name}
            Date of Birth: {student.date_of_birth}
            Address: {student.address}
            Contact Number: {student.contact_number}
            Email: {student.email}
            English Marks: {student.english_marks}
            Physics Marks: {student.physics_marks}
            Chemistry Marks: {student.chemistry_marks}
            Percentage: {student.calculate_percentage()}%
            """
            
            return render(request, 'student/form.html', {
                'form': StudentForm(),
                'student_data': student_data,
                'percentage': student.calculate_percentage()
            })
    else:
        form = StudentForm()
    
    return render(request, 'student/form.html', {'form': form})
