from django.shortcuts import render
from .forms import EmployeePromotionForm
from datetime import datetime

def promotion_eligibility(request):
    if request.method == 'POST':
        form = EmployeePromotionForm(request.POST)
        if form.is_valid():
            date_of_joining = form.cleaned_data['date_of_joining']
            experience_years = (datetime.now().date() - date_of_joining).days // 365
            eligible = experience_years > 5
            eligibility_result = "YES" if eligible else "NO"
            return render(request, 'employee/form.html', {'form': form, 'eligibility_result': eligibility_result})
    else:
        form = EmployeePromotionForm()
    return render(request, 'employee/form.html', {'form': form})
