from django import forms

class EmployeePromotionForm(forms.Form):
    employee_id = forms.ChoiceField(choices=[(1, 'Employee 1'), (2, 'Employee 2')])  # Populate with actual employee IDs
    date_of_joining = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
