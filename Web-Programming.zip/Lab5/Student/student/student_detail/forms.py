from django import forms

class StudentForm(forms.Form):
    name = forms.CharField(max_length=100, required=True)
    dob = forms.DateField(required=True, widget=forms.DateInput(attrs={'type': 'date'}))
    address = forms.CharField(widget=forms.Textarea, required=True)
    contact_number = forms.CharField(max_length=15, required=True)
    email = forms.EmailField(required=True)
    english_marks = forms.IntegerField(min_value=0, max_value=100, required=True)
    physics_marks = forms.IntegerField(min_value=0, max_value=100, required=True)
    chemistry_marks = forms.IntegerField(min_value=0, max_value=100, required=True)
