# student/urls.py
from django.urls import path
from . import views  # this imports your views properly

urlpatterns = [
    path('student-form/', views.student_form, name='student_form'),
]
