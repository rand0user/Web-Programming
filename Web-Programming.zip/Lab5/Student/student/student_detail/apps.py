from django.apps import AppConfig


class StudentDetailConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'student_detail'
