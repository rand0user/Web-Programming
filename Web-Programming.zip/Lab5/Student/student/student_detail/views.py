# views.py
from django.shortcuts import render
from .forms import StudentForm

def student_form(request):
    total_percentage = None
    student_details = None

    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            # Process the form data
            student_details = form.cleaned_data
            total_marks = student_details['english_marks'] + student_details['physics_marks'] + student_details['chemistry_marks']
            total_percentage = (total_marks / 300) * 100  # Total marks is 300 for 3 subjects
    else:
        form = StudentForm()

    return render(request, 'student/student_form.html', {
        'form': form,
        'student_details': student_details,
        'total_percentage': total_percentage
    })
