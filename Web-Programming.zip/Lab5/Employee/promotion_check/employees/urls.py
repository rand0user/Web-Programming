from django.urls import path
from .views import check_promotion

urlpatterns = [
    path('promotion-check/', check_promotion, name='promotion_check'),
]
