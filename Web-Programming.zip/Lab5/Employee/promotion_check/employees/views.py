from django.shortcuts import render
from datetime import datetime, timedelta
from .forms import PromotionCheckForm

def check_promotion(request):
    result = None
    if request.method == 'POST':
        form = PromotionCheckForm(request.POST)
        if form.is_valid():
            doj = form.cleaned_data['date_of_joining']
            experience = (datetime.today().date() - doj).days / 365
            result = "YES" if experience > 5 else "NO"
    else:
        form = PromotionCheckForm()
    
    return render(request, 'employees/promotion_form.html', {'form': form, 'result': result})
