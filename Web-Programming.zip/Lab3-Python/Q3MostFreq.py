from collections import Counter
def most_frequent_words(file_path):
    try:
        with open(file_path, 'r') as file:
            text = file.read()
        words = text.split()
        words = [word.strip('.,!?;:"()[]').lower() for word in words]
        word_count = Counter(words)
        most_common_words = word_count.most_common(10)
        print("10 Most Frequent Words:")
        for word, freq in most_common_words:
            print(f"{word}: {freq}")
    except FileNotFoundError:
        print("The specified file was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

file_path = 'Lab3-Python\input.txt'
most_frequent_words(file_path)